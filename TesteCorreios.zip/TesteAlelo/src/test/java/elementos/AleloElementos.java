package elementos;

import org.openqa.selenium.By;

public class AleloElementos {
	public By Pesquisa = By.id("endereco");
	public By Buscar = By.id("btn_pesquisar");
	public By MensagemCep = By.xpath("//tbody/tr[1]/td[2]");
	public By MensagemLagradouro = By.cssSelector("#resultado-DNEC > tbody > tr:nth-child(29) > td:nth-child(3)");
}
