package test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementos.AleloElementos;
import pages.AleloMetodos;

public class AleloTest {
	
	AleloMetodos metodo = new AleloMetodos();
	AleloElementos elemento =new AleloElementos();
	@Given("^Que acesse o site \"([^\"]*)\"$")
	public void que_acesse_o_site(String arg1) throws Throwable {
		metodo.abrirNavegador(arg1);
	  
	}

	@When("^digito cep$")
	public void digito_cep() throws Throwable {
		metodo.preencher(elemento.Pesquisa, "06253010");
		metodo.clicar(elemento.Buscar);
	   
	}

	@Then("^valido bairro$")
	public void valido_bairro() throws Throwable {
		metodo.esperarElemento(elemento.MensagemCep);
		metodo.validarTexto(elemento.MensagemCep, "Helena Maria");
		metodo.fecharBrowser();
	    
	}
	@When("^digito lagradouro$")
	public void digito_lagradouro() throws Throwable {
		metodo.preencher(elemento.Pesquisa, "Av autonomistas");
		metodo.clicar(elemento.Buscar);
	}

	@Then("^valido endereco")
	public void valido_endereco() throws Throwable {
		metodo.esperarElemento(elemento.MensagemLagradouro);
		metodo.validarTexto(elemento.MensagemLagradouro, "Osasco/SP");
		metodo.fecharBrowser();
	  
	}

}
