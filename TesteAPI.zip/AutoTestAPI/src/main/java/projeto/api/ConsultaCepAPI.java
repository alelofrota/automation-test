package projeto.api;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;

public class ConsultaCepAPI {

    public static Response response;
    public static RequestSpecification requestAPI;
    public static String respJson;
    public static int statusCode;

    public static void urlAcesso(String url) {
            RestAssured.baseURI = url;
            requestAPI = RestAssured.given();
    }

    public static Response metodoGet(String param) {
        if (!(param.equals(null) || param.equals(""))){
            RestAssured.baseURI = RestAssured.baseURI + param;
        }
        System.out.println("Url API Send GET: "+RestAssured.baseURI);
        response = requestAPI.get(RestAssured.baseURI);
        statusCode = response.getStatusCode();
        respJson = response.getBody().prettyPrint();
        System.out.println(respJson);
        System.out.println(statusCode);
        return response;
    }

    public static void validoStatusCode(int statusCodeEsperado){
        Assert.assertEquals("Resultado retornou statuscode diferente do esperado. ",statusCodeEsperado, statusCode);
    }
}
