package projeto.steps;

import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Dados;
import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;
import projeto.api.ConsultaCepAPI;

public class ConsultaCepSteps {

    @Dado ("que tenho acesso a API {string}")
    public void que_tenho_acesso_a_API(String url){
        ConsultaCepAPI.urlAcesso(url);
    }

    @Quando("faço a consulta do cep {string} com método GET")
    public void que_faço_a_consulta_do(String str1) {
        ConsultaCepAPI.metodoGet(str1 + "/json/");
    }

    @Então("valido statuscode {int}")
    public void valido_statuscode(int str1) {
        ConsultaCepAPI.validoStatusCode(str1);
    }

}
