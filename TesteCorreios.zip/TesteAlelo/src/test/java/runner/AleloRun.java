package runner;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(

		monochrome = true,
		features = "src/test/resources/features/",
		glue = "test",
		tags = "@alelo,@ale",
		plugin = { "pretty", "io.qameta.allure.cucumberjvm.AllureCucumberJvm"},
		dryRun = false)
public class AleloRun {

}
